#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class MNQ2LegStrategy : Strategy
	{
		private int MaxContracts;
		private int ProfitTargetPoints;
		private double StopLoss2;
		private double StopLoss3;
		private double PointsChange;
		
		private bool ContractInitialized;
		private double EntryPrice;
		private double CurrentPrice;
		private int NumContracts;
		private double BreakevenAmount;
		private double BreakevenThreshold2;
		private double BreakevenThreshold3;
		private int Breakevens;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Micro NQ Strategy but with 2 entries";
				Name										= "MNQ2LegStrategy";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 9;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.ImmediatelySubmit;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 2;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				MaxContracts					= 3;
				ProfitTargetPoints					= 30;
				StopLoss2					= 14.0;
				StopLoss3					= 10.0;
				PointsChange					= 5.00;
				ContractInitialized         = false;
				NumContracts				= 0;
				BreakevenThreshold2 		= 10.0;
				BreakevenThreshold3 		= 20.0;
				Breakevens					= 0;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;
	
			if (PositionAccount.MarketPosition == MarketPosition.Long) {
				//Long Position Entered
				if (ContractInitialized == false) {
					EntryPrice = PositionAccount.AveragePrice;
					CurrentPrice = EntryPrice;
					ContractInitialized = true;
					NumContracts = 1;
				} else {
					if (GetCurrentBid() - CurrentPrice >= PointsChange && NumContracts < 2) {
						//Entering new contract...
						BreakevenAmount = CurrentPrice;
						CurrentPrice = GetCurrentBid();
						string SignalName = "AutomatedContractBuy1";
						
						SetProfitTarget(
						SignalName,
						CalculationMode.Price,
						CurrentPrice + ProfitTargetPoints
						);
						SetStopLoss(
						SignalName,
						CalculationMode.Price,
						CurrentPrice - StopLoss2,
						false
						);
						
						EnterLong(5, SignalName);
						NumContracts += 1;
						//Finished entering new contract
					}
					
					//Set breakeven for previous contract after certain amount of points
					if (GetCurrentBid() - BreakevenAmount >= BreakevenThreshold2 && Breakevens == 0) {
						//Breakeven for contract 2
						SetStopLoss(
						"AutomatedContractBuy1",
						CalculationMode.Price,
						BreakevenAmount + 1,
						false
						);
						
						BreakevenAmount = CurrentPrice;
						Breakevens += 1;
					} 
				}
			} else if (PositionAccount.MarketPosition == MarketPosition.Short) {
				//Short Position Entered
				if (ContractInitialized == false) {
					EntryPrice = PositionAccount.AveragePrice;
					CurrentPrice = EntryPrice;
					ContractInitialized = true;
					NumContracts = 1;
				} else {
					if (CurrentPrice - GetCurrentAsk() >= PointsChange && NumContracts < 2) {
						//Entering new contract...
						BreakevenAmount = CurrentPrice;
						CurrentPrice = GetCurrentAsk();
						string SignalName = "AutomatedContractSell1";
						
						SetProfitTarget(
						SignalName,
						CalculationMode.Price,
						CurrentPrice - ProfitTargetPoints
						);
						SetStopLoss(
						SignalName,
						CalculationMode.Price,
						CurrentPrice + StopLoss2,
						false
						);
					
						EnterShort(5, SignalName);
						NumContracts += 1;
						//Finished entering new contract
					}
					
					//Set breakeven for previous contract after certain amount of points
					if (BreakevenAmount - GetCurrentAsk() >= BreakevenThreshold2 && Breakevens == 0) {
						//Breakeven for contract 2
						SetStopLoss(
						"AutomatedContractSell1",
						CalculationMode.Price,
						BreakevenAmount - 1,
						false
						);
						
						BreakevenAmount = CurrentPrice;
						Breakevens += 1;
					} 
				}
			} else {
				//Strategy finished
				ContractInitialized = false;
				NumContracts = 0;
				Breakevens = 0;
			}
		}
	}
}
