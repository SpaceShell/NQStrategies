#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class NQScale : Strategy
	{
		private int MaxContracts;
		private int ProfitTargetPoints;
		private double StopLoss2;
		private double StopLoss3;
		private double PointsChange;
		
		private bool ContractInitialized;
		private double EntryPrice;
		private double CurrentPrice;
		private int NumContracts;
		private double BreakevenAmount;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"A custom NQ Strategy with auto breakevem";
				Name										= "NQScale";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 9;
				EntryHandling								= EntryHandling.UniqueEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.ImmediatelySubmit;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 2;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				MaxContracts					= 3;
				ProfitTargetPoints					= 15;
				StopLoss2					= 7.5;
				StopLoss3					= 5.0;
				PointsChange					= 10.00;
				ContractInitialized         = false;
				NumContracts				= 0;
			}
			else if (State == State.Configure)
			{
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;
	
			if (PositionAccount.MarketPosition == MarketPosition.Long) {
				//Long Position Entered
				if (ContractInitialized == false) {
					EntryPrice = PositionAccount.AveragePrice;
					CurrentPrice = EntryPrice;
					ContractInitialized = true;
					NumContracts = 1;
				} else {
					if (GetCurrentBid() - CurrentPrice >= PointsChange) {
						if (NumContracts < 3) {
							//Entering new contract...
							BreakevenAmount = CurrentPrice;
							CurrentPrice = GetCurrentBid();
							string SignalName = NumContracts == 1 ? "AutomatedContractBuy1" : "AutomatedContractBuy2";
							
							SetProfitTarget(
							SignalName,
							CalculationMode.Price,
							CurrentPrice + ProfitTargetPoints
							);
							SetStopLoss(
							SignalName,
							CalculationMode.Price,
							NumContracts == 1 ? CurrentPrice - StopLoss2 : CurrentPrice - StopLoss3,
							false
							);
							
							EnterLong(1, SignalName);
							NumContracts += 1;
							//Finished entering new contract
						}
						
						//Set breakeven for previous contract when new contract is added
						if (NumContracts > 2) {
							SetStopLoss(
							BreakevenAmount != CurrentPrice ? "AutomatedContractBuy1" : "AutomatedContractBuy2",
							CalculationMode.Price,
							BreakevenAmount + 0.5,
							false
							);
							
							BreakevenAmount = CurrentPrice;
						} 
					}
				}
			} else if (PositionAccount.MarketPosition == MarketPosition.Short) {
				//Short Position Entered
				if (ContractInitialized == false) {
					EntryPrice = PositionAccount.AveragePrice;
					CurrentPrice = EntryPrice;
					ContractInitialized = true;
					NumContracts = 1;
				} else {
					if (CurrentPrice - GetCurrentAsk() >= PointsChange) {
						if (NumContracts < 3) {
							//"Entering new contract..."
							BreakevenAmount = CurrentPrice;
							CurrentPrice = GetCurrentAsk();
							string SignalName = NumContracts == 1 ? "AutomatedContractSell1" : "AutomatedContractSell2";
							
							SetProfitTarget(
							SignalName,
							CalculationMode.Price,
							CurrentPrice - ProfitTargetPoints
							);
							SetStopLoss(
							SignalName,
							CalculationMode.Price,
							NumContracts == 1 ? CurrentPrice + StopLoss2 : CurrentPrice + StopLoss3,
							false
							);
						
							EnterShort(1, SignalName);
							NumContracts += 1;
							//"Finished entering new contract"
						}
						
						//Set breakeven for previous contract when new contract is added
						if (NumContracts > 2) {
							SetStopLoss(
							BreakevenAmount != CurrentPrice ? "AutomatedContractSell1" : "AutomatedContractSell2",
							CalculationMode.Price,
							BreakevenAmount - 0.5,
							false
							);
							
							BreakevenAmount = CurrentPrice;
						} 
					}
				}
			} else {
				//"Strategy finished"
				ContractInitialized = false;
				NumContracts = 0;
			}
		}
	}
}
